// Z-Library Performance Optimizer - JavaScript
console.log('🚀 Z-Library Performance Optimizer loaded');

// BLOCK ELEMENTS BEFORE THEY LOAD
function blockElements() {
    // Remove heavy elements from DOM
    const elementsToRemove = [
        // Books Mosaic & Recommendations
        '.books-mosaic',
        '.recommendations',
        '#booksMosaicBoxContainer',
        '.masonry-endless',
        '.masonry',
        '.termsCloud',
        '.termWrap',
        'z-comments',
        '#footer',
        'footer',
        '.footer',
        'header',
        '.header',
        '.sidebar',
        '.menu',
        '.breadcrumb',
        '.pagination',
        '.advertisement',
        '.ads',
        '.banner',
        '.promo',
        '.social-share',
        '.social-media',
        '.share-buttons',
        '.comments',
        '.comment-section',
        '.reviews',
        '.related-books',
        '.related',
        '.similar',
        '.newsletter',
        '.subscribe',
        '.signup',
        '.search-box',
        '.search-form',
        '.category-menu',
        '.tags',
        '.categories',
        '.author-info',
        '.publisher-info',
        '.book-description',
        '.synopsis',
        '.rating',
        '.stars',
        '.reviews-count',
        '.download-count',
        '.views',
        '.popularity',
        '.book-cover',
        '.cover-image',
        '.book-details',
        '.metadata'
    ];

    elementsToRemove.forEach(selector => {
        try {
            const elements = document.querySelectorAll(selector);
            elements.forEach(element => {
                element.remove();
            });
        } catch (e) {
            // Ignore errors
        }
    });
}

// BLOCK IMAGES
function blockImages() {
    const images = document.querySelectorAll('img');
    images.forEach(img => {
        img.remove();
    });
}

// BLOCK CSS BACKGROUNDS
function blockBackgrounds() {
    const style = document.createElement('style');
    style.textContent = `
        * {
            background-image: none !important;
            background: white !important;
        }
    `;
    document.head.appendChild(style);
}

// DISABLE ANIMATIONS
function disableAnimations() {
    const style = document.createElement('style');
    style.textContent = `
        * {
            animation: none !important;
            transition: none !important;
        }
    `;
    document.head.appendChild(style);
}

// OPTIMIZE PERFORMANCE
function optimizePerformance() {
    // Block elements
    blockElements();
    
    // Block images
    blockImages();
    
    // Block backgrounds
    blockBackgrounds();
    
    // Disable animations
    disableAnimations();
    
    console.log('⚡ Performance optimization applied');
}

// RUN IMMEDIATELY
optimizePerformance();

// RUN ON DOM CONTENT LOADED
document.addEventListener('DOMContentLoaded', optimizePerformance);

// RUN ON LOAD
window.addEventListener('load', optimizePerformance);

// RUN PERIODICALLY
setInterval(optimizePerformance, 1000);

// MUTATION OBSERVER - Watch for new elements
const observer = new MutationObserver((mutations) => {
    mutations.forEach((mutation) => {
        if (mutation.type === 'childList') {
            optimizePerformance();
        }
    });
});

// Start observing
observer.observe(document.body, {
    childList: true,
    subtree: true
});

console.log('✅ Z-Library Performance Optimizer active'); 